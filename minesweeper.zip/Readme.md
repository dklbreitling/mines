# Minesweeper-like-game (please don't sue me, Michaelsoft)

In bash type `./gradlew run` to run the game. Tested 