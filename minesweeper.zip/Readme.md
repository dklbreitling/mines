# Minesweeper-like-game (please don't sue me, Michaelsoft)

In bash type `./gradlew run` to run the game. Not tested on Windows (but `gradlew run` or using IntelliJ run button should work). Java 8.

If the game window is too big, adjust `DrawSizeFactor` in `MinesweeperLogic.scala`.

Processing has some issues randomly causing `java.lang.ThreadDeath` when resizing windows sometimes. Please ignore...