package minesweeperlikegamepleasedontsuememichaelsoft.logic

abstract class CellType
case object Hidden extends CellType
case object Visible extends CellType
