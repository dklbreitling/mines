package minesweeperlikegamepleasedontsuememichaelsoft.logic

case class Tile(cellType: CellType, count: Int = 0, hasBomb: Boolean = false, hasFlag: Boolean = false) {}
